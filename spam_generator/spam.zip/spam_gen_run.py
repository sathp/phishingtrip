import numpy as np
import tensorflow as tf

from get_lines_text import *
from get_emails import get_clinton_emails

input_string = "cucumber"

input_string = input("Give me a seed: ")


#define nessecary vars
num_lstm_units = 500
batch_size = 100
num_chars = None
letter_dic = None
reverse_letter_dic = None
max_time_steps = 100
len_str = len(input_string)

#text, num_chars, letter_dic, reverse_letter_dic = get_moby_dick_batches(batch_size, max_time_steps)
text, num_chars, letter_dic, reverse_letter_dic = get_txt_batches("varney.text", batch_size, max_time_steps)

print(letter_dic)

#more vars
num_batches = len(text)

#create LSTM, state for LSTM, and placeholders for feeding
lstm_cell = tf.contrib.rnn.LSTMCell(num_lstm_units) #create our lstm with this number of units
lstm_cell = tf.contrib.rnn.DropoutWrapper(lstm_cell, output_keep_prob=.2) #add dropout for magical reasons
grad_descent_obj = tf.train.AdamOptimizer(.01, name="LSTM_Gradient_Descent") 

#to be used in final output calculation
probability_w_z = tf.random_uniform([num_lstm_units, num_chars], dtype=tf.float64, name="Probability_weights") #when multiplied by the output, creates the distribution for every character
probability_b_z = tf.random_uniform([1, num_chars], dtype=tf.float64, name="Probability_biases") #biases for above weights
probability_w = tf.Variable(initial_value=probability_w_z, name="Probability_weights", dtype=tf.float64, trainable=True) #when multiplied by the output, creates the distribution for every character
probability_b = tf.Variable(initial_value=probability_b_z, name="Probability_biases", dtype=tf.float64, trainable=True) #biases for above weights


#running graph
with tf.variable_scope("run"):
	batch_of_1 = 1
	#placeholders for the feeding dictionary
	input_data_p_r = tf.placeholder(tf.float64, shape=[len_str, batch_of_1, num_chars], name="running_lables")

	p_w = probability_w
	#p_b = probability_b
	p_b = tf.stack([tf.reshape(probability_b, [-1])]*batch_of_1)
	
	input_data = input_data_p_r
	
	#compare calculated prob with next time_step
	
	print("Setting up running")
	
	#run through the batches in the NN
	#outputs, final_state = tf.nn.dynamic_rnn(lstm_cell, input_data, dtype=tf.float64)
	
	#run through the given word
	
	#state = (hidden state, current state) as by api docs
	state = lstm_cell.zero_state(batch_of_1, dtype=tf.float64)
	
	for step in tf.unstack(input_data):
		output, state = lstm_cell(step, state)
	
	temp_logit = tf.nn.softmax(tf.matmul(output, p_w) + p_b)
	output = temp_logit
	
	new_probabilities = []
	new_probabilities.append(temp_logit)
	
	for _ in range(max_time_steps - len(input_string)):
		output, state = lstm_cell(output, state)
		
		#compute extra stuff in the for loop
		temp_logit = tf.nn.softmax(tf.matmul(output, p_w) + p_b)
		output = tf.one_hot([tf.argmax(tf.reshape(temp_logit, [-1]))], num_chars, dtype=tf.float64)
		tf.Print(temp_logit, [temp_logit])
		new_probabilities.append(temp_logit)
	
	probabilities_r = tf.transpose(tf.stack(new_probabilities), [1,0,2])
	
	final_state_r = state

#now run the session on the graph

#create the session
sess = tf.Session()
saver = tf.train.Saver()

#initialize all the variables
init_operation = tf.global_variables_initializer()

#get the losses for the current batch and the total loss
total_loss = 0.0

with sess.as_default():
	sess.run(init_operation)
	saver.restore(sess, "varney")
	#set up a non tensor rep of the state
	numpy_state = (np.zeros([batch_size, num_lstm_units], np.float64), np.zeros([batch_size, num_lstm_units], np.float64))
	
	writer = tf.summary.FileWriter("C:/Users/Krist/Desktop/spam", sess.graph)
	
	#format a string to be completed
	my_string = input_string
	my_string = np.asarray([[get_arr_with_n_as_one(letter_dic[char], num_chars)] for char in my_string])
	
	print(np.asarray(my_string).shape)
	
	
	p, s = sess.run([probabilities_r, final_state_r], feed_dict={input_data_p_r: my_string})
	
	chars_o = ""
	
	for j in p:
		chars_o += str(reverse_letter_dic[np.argmax(j)])
	print(input_string+chars_o)
		
	
sess.close()
