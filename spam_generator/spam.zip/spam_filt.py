import numpy as np
import tensorflow as tf

max_time_steps = 10000
num_lstm_units = 200
batch_size = 100
learning_rate = 0.01

#global objects
lstm_cell = tf.contrib.rnn.LSTMCell(num_lstm_units)
grad_desc_obj = tf.train.GradientDescentOptimizer(learning_rate)
output_weights = tf.Variable(dtype=flaot64, "Final_Weights")
output_biases = tf.Variable(dtype=flaot64, "Final_Biases")

#create the building/intializing graph


#train the NN
with tf.variable_scope("train"):
	email_batch_placeholder = tf.placeholder(tf.float64)
	spam_flag_placeholder = tf.placeholder(tf.float64)
	
	output_weights_ext = tf.reshape(output_weights, [-1])
	output_weights_ext = tf.stack([output_weights]*batch_size)
	output_biases_ext = tf.reshape(output_biases, [-1])
	output_weights_ext = tf.stack([output_weights]*batch_size)
 	
	outputs, state = tf.nn.dynamic_rnn(lstm_cell, email_batch_placeholder, dtype=tf.float64)
	
	last_output = tf.transpose(outputs, [1,2,0])
	last_output = last_output[-1:, :, :]
	
	prob_dist = tf.wx_plus_b(last_output, output_weights_ext, output_biases_ext)
	
	cost = tf.losses.mean_squared_error(spam_flag_placeholder, prob_dist)
	
	minimizer = grad_desc_obj.minimize(cost)
	
	final_state = state
	

with tf.Session() as sess:
	for email_batch in emails:
		__, loss, _ = sess.run([final_state, cost, minimizer], feed_dict={email_batch_placeholder: email_batch["data"], spam_flag_placeholder: email_batch["is_spam"]})
		