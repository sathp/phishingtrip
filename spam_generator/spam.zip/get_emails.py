import sqlite3
conn = sqlite3.connect("hillary-clinton-emails\database.sqlite")

def get_arr_with_n_as_one(n, leng):
	li = [0]*leng
	li[n] = 1.0
	return li

def get_clinton_emails(batch_size, sample_length):
	total_text = ""

	for row in conn.execute("SELECT RawText FROM Emails"):
		total_text += row[0]
	
	text = total_text.lower()
	
	letter_dic = {}
	reverse_letter_dic = {}
	
	id = 0
	
	for char in text:
		if(char in letter_dic):
			pass
		else:
			letter_dic[char] = id
			reverse_letter_dic[id] = char
			id += 1
					
	num_chars = id
	
	ttext = []
	
	for place in range(len(text)//sample_length):
		ttext.append([get_arr_with_n_as_one(letter_dic[char], num_chars) for char in text[place*sample_length:(place+1)*sample_length]])
	
	text = ttext
	
	ttext = []
	
	for batch in range(len(text)//batch_size):
		ttext.append(text[batch*batch_size:(batch+1)*batch_size])
	
	text = ttext
	
	print(len(text), len(text[0]), len(text[0][0]))
	
	return text, num_chars, letter_dic, reverse_letter_dic
	
#total_text = ""

#for row in conn.execute("SELECT RawText FROM Emails"):
	#total_text += " " + row[0]
	
#print(total_text)